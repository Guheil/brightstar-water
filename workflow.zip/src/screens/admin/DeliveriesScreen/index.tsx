'use client';

import { Eye } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import EmptyState from '@/components/ui/EmptyState';
import StatusText from '@/components/ui/StatusText';
import { useAppStore } from '@/store';
import type { Delivery } from '@/types';
import { formatPhp, getEffectiveScheduleText } from '@/utils';
import AdminDataTable from '../components/AdminDataTable';
import AdminEntityActionMenu from '../components/AdminEntityActionMenu';
import type { AdminDataColumn } from '../components/AdminDataTable/interface';
import AdminPageHeader from '../components/AdminPageHeader';
import AdminMetricStrip from '../components/AdminMetricStrip';
import { getStatusTone, humanize } from '../utils';
import {
  FilterBar,
  FilterField,
  FilterOption,
  ResetButton,
  ResultCount,
  Root,
  TableLink,
} from './elements';
import type { DeliveriesScreenProps } from './interface';

export default function DeliveriesScreen({ className }: DeliveriesScreenProps) {
  const router = useRouter();
  const deliveries = useAppStore((state) => state.deliveries.records);
  const deliverers = useAppStore((state) => state.deliveries.deliverers);
  const orders = useAppStore((state) => state.orders.records);
  const customers = useAppStore((state) => state.customers.records);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [delivererId, setDelivererId] = useState('all');
  const [date, setDate] = useState('');

  const deliveryMetrics = [
    { label: 'Unassigned', value: deliveries.filter((delivery) => delivery.status === 'unassigned').length, tone: 'warning' as const },
    { label: 'Assigned', value: deliveries.filter((delivery) => ['assigned', 'accepted'].includes(delivery.status)).length, tone: 'gas' as const },
    { label: 'In progress', value: deliveries.filter((delivery) => delivery.status === 'out_for_delivery').length, tone: 'water' as const },
    { label: 'Needs attention', value: deliveries.filter((delivery) => delivery.status === 'failed').length, tone: 'error' as const },
    { label: 'Delivered', value: deliveries.filter((delivery) => delivery.status === 'delivered').length, tone: 'success' as const },
  ];

  const filteredDeliveries = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return deliveries
      .filter((delivery) => {
        const order = orders.find((item) => item.id === delivery.orderId);
        const customer = customers.find((item) => item.id === delivery.customerId);
        const matchesQuery =
          !normalized ||
          order?.reference.toLowerCase().includes(normalized) ||
          customer?.displayName.toLowerCase().includes(normalized) ||
          delivery.address.area.toLowerCase().includes(normalized);
        const matchesStatus = status === 'all' || delivery.status === status;
        const matchesDeliverer =
          delivererId === 'all' ||
          (delivererId === 'unassigned'
            ? !delivery.delivererId
            : delivery.delivererId === delivererId);
        const matchesDate = !date || delivery.schedule.date === date;
        return matchesQuery && matchesStatus && matchesDeliverer && matchesDate;
      })
      .sort((a, b) => {
        const dateOrder = a.schedule.date.localeCompare(b.schedule.date);
        return dateOrder || a.schedule.windowLabel.localeCompare(b.schedule.windowLabel);
      });
  }, [customers, date, delivererId, deliveries, orders, query, status]);

  const columns: readonly AdminDataColumn<Delivery>[] = [
    {
      key: 'order',
      label: 'Order',
      render: (delivery) => {
        const order = orders.find((item) => item.id === delivery.orderId);
        return (
          <TableLink href={`/admin/deliveries/${delivery.id}`}>
            {order?.reference ?? delivery.id}
          </TableLink>
        );
      },
    },
    {
      key: 'customer',
      label: 'Customer',
      render: (delivery) =>
        customers.find((item) => item.id === delivery.customerId)?.displayName ??
        delivery.address.recipientName,
    },
    {
      key: 'schedule',
      label: 'Schedule',
      render: (delivery) => getEffectiveScheduleText(delivery.schedule),
    },
    {
      key: 'area',
      label: 'Delivery area',
      render: (delivery) => `${delivery.address.area} · ${delivery.address.distanceKm} km`,
    },
    {
      key: 'payment',
      label: 'Payment',
      render: (delivery) =>
        delivery.paymentMethod === 'cod'
          ? `COD · ${formatPhp(delivery.amountToCollectCentavos)}`
          : 'GCash · no cash collection',
    },
    {
      key: 'deliverer',
      label: 'Deliverer',
      render: (delivery) =>
        deliverers.find((item) => item.id === delivery.delivererId)?.displayName ??
        'Unassigned',
    },
    {
      key: 'status',
      label: 'Status',
      render: (delivery) => (
        <StatusText tone={getStatusTone(delivery.status)}>
          {humanize(delivery.status)}
        </StatusText>
      ),
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (delivery) => (
        <AdminEntityActionMenu
          actions={[
            {
              label: 'Open delivery workflow',
              icon: Eye,
              onSelect: () => router.push(`/admin/deliveries/${delivery.id}`),
            },
          ]}
          ariaLabel={`Actions for delivery ${delivery.id}`}
        />
      ),
    },
  ];

  const resetFilters = () => {
    setQuery('');
    setStatus('all');
    setDelivererId('all');
    setDate('');
  };

  return (
    <Root className={className}>
      <AdminPageHeader
        description="Assign drivers, monitor delivery progress, and resolve fulfillment exceptions."
        title="Deliveries"
      />

      <AdminMetricStrip ariaLabel="Delivery status summary" items={deliveryMetrics} />

      <FilterBar aria-label="Delivery filters">
        <FilterField
          label="Search order, customer, or area"
          onChange={(event) => setQuery(event.target.value)}
          value={query}
        />
        <FilterField
          label="Status"
          onChange={(event) => setStatus(event.target.value)}
          select
          value={status}
        >
          <FilterOption value="all">All statuses</FilterOption>
          <FilterOption value="unassigned">Unassigned</FilterOption>
          <FilterOption value="assigned">Assigned</FilterOption>
          <FilterOption value="accepted">Accepted</FilterOption>
          <FilterOption value="out_for_delivery">Out for delivery</FilterOption>
          <FilterOption value="delivered">Delivered</FilterOption>
          <FilterOption value="failed">Failed</FilterOption>
          <FilterOption value="cancelled">Cancelled</FilterOption>
        </FilterField>
        <FilterField
          label="Deliverer"
          onChange={(event) => setDelivererId(event.target.value)}
          select
          value={delivererId}
        >
          <FilterOption value="all">All deliverers</FilterOption>
          <FilterOption value="unassigned">Unassigned</FilterOption>
          {deliverers.map((deliverer) => (
            <FilterOption key={deliverer.id} value={deliverer.id}>
              {deliverer.displayName}
            </FilterOption>
          ))}
        </FilterField>
        <FilterField
          label="Schedule date"
          onChange={(event) => setDate(event.target.value)}
          slotProps={{ inputLabel: { shrink: true } }}
          type="date"
          value={date}
        />
        <ResetButton onClick={resetFilters}>Clear filters</ResetButton>
      </FilterBar>

      {filteredDeliveries.length ? (
        <>
          <AdminDataTable
            ariaLabel="Admin deliveries"
            columns={columns}
            getRowKey={(delivery) => delivery.id}
            rows={filteredDeliveries}
          />
          <ResultCount>{filteredDeliveries.length} matching deliveries</ResultCount>
        </>
      ) : (
        <EmptyState
          action={<ResetButton onClick={resetFilters}>Clear filters</ResetButton>}
          description="Change the search, status, deliverer, or schedule date."
          title="No deliveries match these filters"
        />
      )}
    </Root>
  );
}
