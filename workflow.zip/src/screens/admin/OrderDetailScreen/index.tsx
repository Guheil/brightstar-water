'use client';

import { useEffect, useState } from 'react';
import EmptyState from '@/components/ui/EmptyState';
import LoadingState from '@/components/ui/LoadingState';
import Notice from '@/components/ui/Notice';
import StatusText from '@/components/ui/StatusText';
import { fetchPublicCatalog } from '@/lib/catalog/client';
import {
  adminAssignDelivery, adminConfirmOrder, adminPrepareOrder, adminResolveCancellation,
  adminUpdateRefund, adminVerifyPayment, fetchAdminPaymentProof, fetchOperationalOrderDetail,
} from '@/lib/orders/client';
import { useAppStore } from '@/store';
import type { RefundStatus } from '@/types';
import { canRequestRefund, formatPhp, getEstimatedScheduleText, getPreferredScheduleText } from '@/utils';
import AdminConfirmDialog from '../components/AdminConfirmDialog';
import AdminPageHeader from '../components/AdminPageHeader';
import { formatDateTime, getStatusTone, humanize } from '../utils';
import {
  ActionButton,
  ActionCopy,
  ActionField,
  ActionOption,
  ActionPanel,
  ActionTitle,
  ContentGrid,
  DangerButton,
  DetailList,
  DetailTerm,
  DetailValue,
  EmptyActionLink,
  InlineLink,
  ItemList,
  ItemMeta,
  ItemName,
  ItemRow,
  MainColumn,
  PaymentProofImage,
  Root,
  SecondaryButton,
  Section,
  SectionTitle,
  SideColumn,
  Timeline,
  TimelineItem,
  TimelineLabel,
  TimelineMeta,
  Totals,
  TotalValue,
} from './elements';
import type { OrderDetailScreenProps } from './interface';

type Feedback = { tone: 'success' | 'error'; title: string; message: string };

type PendingAction =
  | { kind: 'confirm_order'; title: string; description: string; label: string }
  | { kind: 'prepare_order'; title: string; description: string; label: string }
  | { kind: 'assign'; title: string; description: string; label: string }
  | { kind: 'verify_payment'; title: string; description: string; label: string }
  | { kind: 'approve_cancellation'; title: string; description: string; label: string }
  | { kind: 'reject_cancellation'; title: string; description: string; label: string }
  | {
      kind: 'refund';
      target: RefundStatus;
      title: string;
      description: string;
      label: string;
    };

export default function OrderDetailScreen({ orderId }: OrderDetailScreenProps) {
  const order = useAppStore((state) =>
    state.orders.records.find((item) => item.id === orderId),
  );
  const customer = useAppStore((state) =>
    state.customers.records.find((item) => item.id === order?.customerId),
  );
  const payment = useAppStore((state) =>
    state.payments.records.find((item) => item.orderId === orderId),
  );
  const delivery = useAppStore((state) =>
    state.deliveries.records.find((item) => item.orderId === orderId),
  );
  const deliverers = useAppStore((state) => state.deliveries.deliverers);
  const mergeOperationalSnapshot = useAppStore((state) => state.commands.mergeOperationalSnapshot);
  const syncCatalogSnapshot = useAppStore((state) => state.commands.syncCatalogSnapshot);
  const [selectedDeliverer, setSelectedDeliverer] = useState('');
  const [reference, setReference] = useState('');
  const [reviewNote, setReviewNote] = useState('');
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [pendingAction, setPendingAction] = useState<PendingAction | null>(null);
  const [paymentProof, setPaymentProof] = useState<{ paymentId: string; url: string } | null>(null);
  const [checkedOrderId, setCheckedOrderId] = useState<string | null>(null);
  const detailChecked = Boolean(order) || checkedOrderId === orderId;
  const paymentProofUrl = paymentProof?.paymentId === payment?.id
    ? paymentProof?.url ?? ''
    : '';

  useEffect(() => {
    if (order) return;
    const controller = new AbortController();
    void fetchOperationalOrderDetail(orderId, controller.signal)
      .then((snapshot) => mergeOperationalSnapshot(snapshot))
      .catch(() => undefined)
      .finally(() => { if (!controller.signal.aborted) setCheckedOrderId(orderId); });
    return () => controller.abort();
  }, [mergeOperationalSnapshot, order, orderId]);


  useEffect(() => {
    let active = true;
    const paymentId = payment?.id;
    if (!paymentId || !payment.proofAvailable) return () => { active = false; };
    void fetchAdminPaymentProof(paymentId)
      .then((url) => { if (active) setPaymentProof({ paymentId, url }); })
      .catch(() => { if (active) setPaymentProof(null); });
    return () => { active = false; };
  }, [payment?.id, payment?.proofAvailable]);

  if (!order && !detailChecked) return <LoadingState label="Loading order" description="Retrieving the latest order state." />;

  if (!order) {
    return (
      <EmptyState
        action={<EmptyActionLink href="/admin/orders">Return to orders</EmptyActionLink>}
        description="The requested order could not be found."
        title="Order not found"
      />
    );
  }

  const executePendingAction = async () => {
    if (!pendingAction) return;
    try {
      switch (pendingAction.kind) {
        case 'confirm_order': await adminConfirmOrder(order.id); break;
        case 'prepare_order': await adminPrepareOrder(order.id); break;
        case 'assign': {
          const effectiveDeliverer = selectedDeliverer || delivery?.delivererId;
          if (!effectiveDeliverer) {
            setFeedback({ tone: 'error', title: 'Choose a deliverer', message: 'Select an available deliverer before assigning this order.' });
            setPendingAction(null);
            return;
          }
          await adminAssignDelivery(order.id, effectiveDeliverer);
          break;
        }
        case 'verify_payment': await adminVerifyPayment(order.id, reference); break;
        case 'approve_cancellation': await adminResolveCancellation(order.id, 'approve', reviewNote); break;
        case 'reject_cancellation': await adminResolveCancellation(order.id, 'reject', reviewNote); break;
        case 'refund': await adminUpdateRefund(order.id, pendingAction.target, reviewNote); break;
      }
      const [operations, catalog] = await Promise.all([fetchOperationalOrderDetail(order.id), fetchPublicCatalog()]);
      mergeOperationalSnapshot(operations);
      syncCatalogSnapshot(catalog);
      setFeedback({ tone: 'success', title: 'Order updated', message: 'Order information updated.' });
    } catch (error) {
      setFeedback({ tone: 'error', title: 'Update failed', message: error instanceof Error ? error.message : 'The order could not be updated.' });
    } finally {
      setPendingAction(null);
    }
  };

  const cancellationRequested = order.cancellation?.status === 'requested';
  const canBeginRefund = Boolean(
    payment && canRequestRefund(order, payment.status),
  );
  const canAssignDelivery = Boolean(
    delivery &&
      ['confirmed', 'preparing', 'assigned_for_delivery'].includes(order.status) &&
      ['unassigned', 'assigned', 'accepted'].includes(delivery.status),
  );

  return (
    <Root>
      <AdminPageHeader
        backHref="/admin/orders"
        backLabel="Back to orders"
        description="Review fulfillment, payment, delivery, inventory, loyalty, and exception state in one workspace."
        title={order.reference}
      />

      {feedback ? (
        <Notice title={feedback.title} tone={feedback.tone}>
          {feedback.message}
        </Notice>
      ) : null}

      <ContentGrid>
        <MainColumn>
          <Section>
            <SectionTitle>Order and customer</SectionTitle>
            <DetailList>
              <DetailTerm>Status</DetailTerm>
              <DetailValue>
                <StatusText tone={getStatusTone(order.status)}>
                  {humanize(order.status)}
                </StatusText>
              </DetailValue>
              <DetailTerm>Customer</DetailTerm>
              <DetailValue>
                {customer ? (
                  <InlineLink href={`/admin/accounts/${customer.id}`}>
                    {customer.displayName}
                  </InlineLink>
                ) : (
                  'Unknown customer'
                )}
              </DetailValue>
              <DetailTerm>Contact</DetailTerm>
              <DetailValue>{customer?.phonePlaceholder ?? 'Not available'}</DetailValue>
              <DetailTerm>Placed</DetailTerm>
              <DetailValue>{formatDateTime(order.placedAt)}</DetailValue>
              <DetailTerm>Estimated arrival</DetailTerm>
              <DetailValue>{getEstimatedScheduleText(order.deliverySchedule)}</DetailValue>
              <DetailTerm>Customer preference</DetailTerm>
              <DetailValue>{getPreferredScheduleText(order.deliverySchedule) ?? 'Earliest available'}</DetailValue>
              <DetailTerm>Customer note</DetailTerm>
              <DetailValue>{order.customerNote ?? 'No customer note.'}</DetailValue>
              <DetailTerm>Inventory state</DetailTerm>
              <DetailValue>{humanize(order.inventoryReservationStatus)}</DetailValue>
            </DetailList>
          </Section>

          <Section>
            <SectionTitle>Products and totals</SectionTitle>
            <ItemList>
              {order.items.map((item) => (
                <ItemRow key={item.productId}>
                  <div>
                    <ItemName>{item.name}</ItemName>
                    <ItemMeta>{item.sku}</ItemMeta>
                  </div>
                  <ItemMeta>× {item.quantity}</ItemMeta>
                  <ItemMeta>{formatPhp(item.lineTotalCentavos)}</ItemMeta>
                </ItemRow>
              ))}
            </ItemList>
            <Totals>
              <DetailTerm>Subtotal</DetailTerm>
              <TotalValue>{formatPhp(order.totals.subtotalCentavos)}</TotalValue>
              <DetailTerm>Delivery fee</DetailTerm>
              <TotalValue>{formatPhp(order.totals.deliveryFeeCentavos)}</TotalValue>
              {order.totals.loyaltyDiscountCentavos > 0 ? (
                <>
                  <DetailTerm>Loyalty discount</DetailTerm>
                  <TotalValue>−{formatPhp(order.totals.loyaltyDiscountCentavos)}</TotalValue>
                </>
              ) : null}
              <DetailTerm>Total</DetailTerm>
              <TotalValue>{formatPhp(order.totals.totalCentavos)}</TotalValue>
            </Totals>
          </Section>

          <Section>
            <SectionTitle>Payment and delivery</SectionTitle>
            <DetailList>
              <DetailTerm>Payment method</DetailTerm>
              <DetailValue>{order.paymentMethod.toUpperCase()}</DetailValue>
              <DetailTerm>Payment status</DetailTerm>
              <DetailValue>
                {payment ? (
                  <StatusText tone={getStatusTone(payment.status)}>
                    {humanize(payment.status)}
                  </StatusText>
                ) : (
                  'No payment record'
                )}
              </DetailValue>
              <DetailTerm>Payment reference</DetailTerm>
              <DetailValue>{payment?.reference ?? 'Not recorded'}</DetailValue>
              <DetailTerm>Delivery state</DetailTerm>
              <DetailValue>
                {delivery ? (
                  <InlineLink href={`/admin/deliveries/${delivery.id}`}>
                    {humanize(delivery.status)}
                  </InlineLink>
                ) : (
                  'No delivery record'
                )}
              </DetailValue>
              <DetailTerm>Assigned deliverer</DetailTerm>
              <DetailValue>
                {deliverers.find((item) => item.id === delivery?.delivererId)
                  ?.displayName ?? 'Unassigned'}
              </DetailValue>
              <DetailTerm>Loyalty effect</DetailTerm>
              <DetailValue>
                {order.loyalty.pointsRedeemed} redeemed · {order.loyalty.pointsAwarded} awarded · {order.loyalty.pointsPending} pending{order.loyalty.redemptionRestoredAt ? ' · redemption restored' : ''}
              </DetailValue>
            </DetailList>
          </Section>

          {order.cancellation ? (
            <Section>
              <SectionTitle>Cancellation record</SectionTitle>
              <DetailList>
                <DetailTerm>Status</DetailTerm>
                <DetailValue>{humanize(order.cancellation.status)}</DetailValue>
                <DetailTerm>Reason</DetailTerm>
                <DetailValue>{order.cancellation.reason}</DetailValue>
                <DetailTerm>Review note</DetailTerm>
                <DetailValue>{order.cancellation.reviewNote ?? 'Not reviewed yet'}</DetailValue>
              </DetailList>
            </Section>
          ) : null}

          {order.refund ? (
            <Section>
              <SectionTitle>Refund record</SectionTitle>
              <DetailList>
                <DetailTerm>Status</DetailTerm>
                <DetailValue>{humanize(order.refund.status)}</DetailValue>
                <DetailTerm>Amount</DetailTerm>
                <DetailValue>{formatPhp(order.refund.amountCentavos)}</DetailValue>
                <DetailTerm>Reason</DetailTerm>
                <DetailValue>{order.refund.reason}</DetailValue>
                <DetailTerm>Resolution note</DetailTerm>
                <DetailValue>{order.refund.resolutionNote ?? 'Not resolved yet'}</DetailValue>
              </DetailList>
            </Section>
          ) : null}

          <Section>
            <SectionTitle>Order timeline</SectionTitle>
            <Timeline>
              {[...order.events].reverse().map((event) => (
                <TimelineItem key={event.id}>
                  <TimelineLabel>{event.label}</TimelineLabel>
                  <TimelineMeta>
                    {formatDateTime(event.occurredAt)} · {humanize(event.actorRole)}
                  </TimelineMeta>
                  {event.description ? <TimelineMeta>{event.description}</TimelineMeta> : null}
                </TimelineItem>
              ))}
            </Timeline>
          </Section>
        </MainColumn>

        <SideColumn>
          {order.status === 'pending_review' ? (
            <ActionPanel>
              <ActionTitle>Review order</ActionTitle>
              <ActionCopy>Confirming allows preparation and delivery assignment.</ActionCopy>
              <ActionButton
                onClick={() =>
                  setPendingAction({
                    kind: 'confirm_order',
                    title: 'Confirm this order?',
                    description:
                      'The order will move to Confirmed and become eligible for preparation and assignment.',
                    label: 'Confirm order',
                  })
                }
              >
                Confirm order
              </ActionButton>
            </ActionPanel>
          ) : null}

          {order.status === 'confirmed' ? (
            <ActionPanel>
              <ActionTitle>Preparation</ActionTitle>
              <ActionCopy>Mark the order as actively being prepared.</ActionCopy>
              <ActionButton
                onClick={() =>
                  setPendingAction({
                    kind: 'prepare_order',
                    title: 'Start order preparation?',
                    description:
                      'Customers will see the shared order state change to Preparing.',
                    label: 'Start preparation',
                  })
                }
              >
                Start preparation
              </ActionButton>
            </ActionPanel>
          ) : null}

          {delivery && canAssignDelivery ? (
            <ActionPanel>
              <ActionTitle>Delivery assignment</ActionTitle>
              <ActionCopy>Only available deliverers can be selected.</ActionCopy>
              <ActionField
                label="Deliverer"
                onChange={(event) => setSelectedDeliverer(event.target.value)}
                select
                value={selectedDeliverer || delivery.delivererId || ''}
              >
                {deliverers
                  .filter((item) => item.status === 'available')
                  .map((deliverer) => (
                    <ActionOption key={deliverer.id} value={deliverer.id}>
                      {deliverer.displayName}
                    </ActionOption>
                  ))}
              </ActionField>
              <ActionButton
                onClick={() =>
                  setPendingAction({
                    kind: 'assign',
                    title: delivery.delivererId
                      ? 'Reassign this delivery?'
                      : 'Assign this delivery?',
                    description:
                      'The selected deliverer queue and the customer order state will update together.',
                    label: delivery.delivererId ? 'Reassign delivery' : 'Assign delivery',
                  })
                }
              >
                {delivery.delivererId ? 'Reassign delivery' : 'Assign delivery'}
              </ActionButton>
            </ActionPanel>
          ) : null}

          {payment?.method === 'gcash' && payment.status === 'awaiting_verification' ? (
            <ActionPanel>
              <ActionTitle>GCash verification</ActionTitle>
              <ActionCopy>Review the customer’s payment screenshot, then record the payment reference if it is visible.</ActionCopy>
              {paymentProofUrl ? (
                <>
                  <PaymentProofImage
                    alt="Customer GCash payment screenshot"
                    src={paymentProofUrl}
                  />
                  <ActionCopy>Payment screenshot</ActionCopy>
                </>
              ) : (
                <ActionCopy>No payment screenshot was attached to this order.</ActionCopy>
              )}
              <ActionField
                label="Payment reference (optional)"
                onChange={(event) => setReference(event.target.value)}
                value={reference}
              />
              <ActionButton
                onClick={() =>
                  setPendingAction({
                    kind: 'verify_payment',
                    title: 'Verify this payment?',
                    description:
                      'The payment will be marked as verified using the supplied reference.',
                    label: 'Verify payment',
                  })
                }
              >
                Verify payment
              </ActionButton>
            </ActionPanel>
          ) : null}

          {cancellationRequested ? (
            <ActionPanel>
              <ActionTitle>Cancellation review</ActionTitle>
              <ActionCopy>Approval may release reserved inventory and cancel delivery.</ActionCopy>
              <ActionField
                label="Review note (optional)"
                multiline
                onChange={(event) => setReviewNote(event.target.value)}
                rows={3}
                value={reviewNote}
              />
              <ActionButton
                onClick={() =>
                  setPendingAction({
                    kind: 'approve_cancellation',
                    title: 'Approve cancellation?',
                    description:
                      'The order will be cancelled and reserved stock may return to availability.',
                    label: 'Approve cancellation',
                  })
                }
              >
                Approve cancellation
              </ActionButton>
              <DangerButton
                onClick={() =>
                  setPendingAction({
                    kind: 'reject_cancellation',
                    title: 'Reject cancellation?',
                    description:
                      'The request will be closed as rejected and the order will keep its current workflow state.',
                    label: 'Reject request',
                  })
                }
              >
                Reject request
              </DangerButton>
            </ActionPanel>
          ) : null}

          {canBeginRefund ? (
            <ActionPanel>
              <ActionTitle>Refund workflow</ActionTitle>
              <ActionCopy>Start a refund record for this eligible payment.</ActionCopy>
              <ActionButton
                onClick={() =>
                  setPendingAction({
                    kind: 'refund',
                    target: 'pending',
                    title: 'Start refund review?',
                    description:
                      'A pending refund will be recorded against this order and payment.',
                    label: 'Start refund',
                  })
                }
              >
                Start refund
              </ActionButton>
            </ActionPanel>
          ) : null}

          {order.refund && ['pending', 'processing'].includes(order.refund.status) ? (
            <ActionPanel>
              <ActionTitle>Advance refund</ActionTitle>
              <ActionCopy>Record a note before resolving the refund.</ActionCopy>
              <ActionField
                label="Refund note (optional)"
                multiline
                onChange={(event) => setReviewNote(event.target.value)}
                rows={3}
                value={reviewNote}
              />
              {order.refund.status === 'pending' ? (
                <ActionButton
                  onClick={() =>
                    setPendingAction({
                      kind: 'refund',
                      target: 'processing',
                      title: 'Move refund to processing?',
                      description:
                        'The refund will remain unresolved and move to the processing state.',
                      label: 'Mark processing',
                    })
                  }
                >
                  Mark processing
                </ActionButton>
              ) : (
                <ActionButton
                  onClick={() =>
                    setPendingAction({
                      kind: 'refund',
                      target: 'refunded',
                      title: 'Mark refund complete?',
                      description:
                        'The payment and refund records will be marked as refunded.',
                      label: 'Mark refunded',
                    })
                  }
                >
                  Mark refunded
                </ActionButton>
              )}
              <DangerButton
                onClick={() =>
                  setPendingAction({
                    kind: 'refund',
                    target: 'rejected',
                    title: 'Reject this refund?',
                    description:
                      'The refund record will be closed as rejected with the current note.',
                    label: 'Reject refund',
                  })
                }
              >
                Reject refund
              </DangerButton>
            </ActionPanel>
          ) : null}

          {!['pending_review', 'confirmed'].includes(order.status) &&
          !cancellationRequested &&
          !canBeginRefund &&
          !order.refund &&
          !canAssignDelivery ? (
            <ActionPanel>
              <ActionTitle>No Admin action required</ActionTitle>
              <ActionCopy>
                This order is waiting for its next role-specific workflow event or is complete.
              </ActionCopy>
              {delivery ? (
                <SecondaryButton href={`/admin/deliveries/${delivery.id}`}>
                  Review delivery
                </SecondaryButton>
              ) : null}
            </ActionPanel>
          ) : null}
        </SideColumn>
      </ContentGrid>

      <AdminConfirmDialog
        confirmLabel={pendingAction?.label ?? 'Confirm'}
        description={pendingAction?.description ?? ''}
        onClose={() => setPendingAction(null)}
        onConfirm={() => void executePendingAction()}
        open={Boolean(pendingAction)}
        title={pendingAction?.title ?? 'Confirm update'}
      />
    </Root>
  );
}
