declare namespace JSX { interface IntrinsicElements { [elemName: string]: any } }
declare module 'react/jsx-runtime' { export const jsx: any; export const jsxs: any; export const Fragment: any; }
declare module 'react' {
  export type ReactNode = any;
  export type CSSProperties = Record<string, string | number | undefined>;
  export type ComponentPropsWithoutRef<T> = any;
  export type SetStateAction<T> = T | ((prev: T) => T);
  export type Dispatch<T> = (value: T) => void;
  export type ChangeEvent<T = any> = { target: T };
  export type KeyboardEvent<T = any> = any;
  export const Fragment: any;
  export function useState<T>(initial: T | (() => T)): [T, Dispatch<SetStateAction<T>>];
  export function useEffect(effect: () => void | (() => void), deps?: readonly any[]): void;
  export function useMemo<T>(factory: () => T, deps: readonly any[]): T;
  export function useCallback<T extends (...args: any[]) => any>(fn: T, deps: readonly any[]): T;
  export function useDeferredValue<T>(value: T): T;
  export function useRef<T>(initial: T): { current: T };
  export function useRef<T>(initial: T | null): { current: T | null };
  export function useSyncExternalStore<T>(subscribe: any, getSnapshot: () => T, getServerSnapshot?: () => T): T;
  export function forwardRef<T, P = {}>(render: (props: P, ref: any) => any): any;
}
declare module '@mui/material/*' { const Component: any; export default Component; }
declare module '@mui/material/styles' {
  export type Theme = any; export type Components<T = any> = any; export type TypographyVariantsOptions = any; export type PaletteOptions = any; export type ShapeOptions = any; export type BreakpointsOptions = any; export type Shadows = any; export type TransitionsOptions = any;
  export const styled: any; export const createTheme: any; export const ThemeProvider: any; export const alpha: any; export const darken: any; export const lighten: any;
}
declare module '@mui/material-nextjs/v16-appRouter' { export const AppRouterCacheProvider: any; }
declare module 'next' { export type Metadata = any; export type NextConfig = any; }
declare module 'next/image' { const Image: any; export default Image; }
declare module 'next/link' { const Link: any; export default Link; }
declare module 'next/dynamic' { const dynamic: any; export default dynamic; }
declare module 'next/navigation' { export const useRouter: any; export const usePathname: any; export const redirect: any; export const notFound: any; }
declare module 'next/font/google' { export const IBM_Plex_Sans: any; export const IBM_Plex_Serif: any; }
declare module 'lucide-react' { const x: any; export = x; }
declare module 'maplibre-gl' { export const Map: any; export const Marker: any; }
declare module '@gsap/react' { export const useGSAP: any; }
declare module 'gsap' { const gsap: any; export default gsap; }
declare module 'lenis' { const Lenis: any; export default Lenis; }
declare module 'react-hook-form' { export const useForm: any; export type SubmitHandler<T> = (data: T) => void; }
declare module '@hookform/resolvers/zod' { export const zodResolver: any; }
declare module 'zod' { export const z: any; }
declare module '@testing-library/jest-dom/vitest' {}
declare module '@testing-library/react' { export const render: any; export const screen: any; }
declare module '@testing-library/user-event' { const u: any; export default u; }
declare module 'vitest/config' { export const defineConfig: any; }
