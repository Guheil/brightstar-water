declare const process: { cwd(): string };
declare module 'zustand' {
  export type StateCreator<T> = (
    set: (partial: Partial<T> | ((state: T) => Partial<T>)) => void,
    get: () => T,
  ) => T;
  export interface UseBoundStore<T> {
    (): T;
    <U>(selector: (state: T) => U): U;
    getState(): T;
    setState(partial: Partial<T> | ((state: T) => Partial<T>)): void;
  }
  export function create<T>(): (initializer: StateCreator<T>) => UseBoundStore<T>;
}
declare module 'zustand/react/shallow' {
  export function useShallow<T, U>(selector: (state: T) => U): (state: T) => U;
}
declare module 'vitest' {
  export const describe: any;
  export const it: any;
  export const test: any;
  export const expect: any;
  export const beforeEach: any;
  export const afterEach: any;
  export const vi: any;
}
declare module 'node:fs' { export const readFileSync: any; export const existsSync: any; }
declare module 'node:path' { export const resolve: any; export const join: any; }
declare module 'node:url' { export const fileURLToPath: any; }
